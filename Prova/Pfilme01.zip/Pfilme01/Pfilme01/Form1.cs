﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[3, 2];
            string auxiliar = "";
            double media = 0;
            string saida = 0;

            for (int i = 0; i < 3; i++)
            {

                for (int j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}ª nota da pessoa {i + 1}, Entrada de notas");

                    if (!double.TryParse(auxiliar, out notas[i, j]) || (notas[i, j] < 0 && notas[i, j] > 10))
                    {
                        MessageBox.Show("Nota Inválida");
                        i--;

                    }

                    else
                    {
                        media += notas[i, j];

                    }

                    media = media / 3;

                    listBoxNotas.Show($"Pessoa{i + 1}:Filme{j + 1}:{notas[i, j]}/n Media Filme{j + 1}:{media}"]);
        }


    }





}


    }





