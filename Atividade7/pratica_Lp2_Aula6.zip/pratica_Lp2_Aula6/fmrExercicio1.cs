﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pratica_Lp2_Aula6
{
    public partial class fmrExercicio1 : Form
    {
        public fmrExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspaco_Click(object sender, EventArgs e)
        {
            int qtdeEspaco = 0;

            for (int i = 0; i < richTextFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(richTextFrase.Text[i]))
                    qtdeEspaco++;
            }
            MessageBox.Show($"A frase possui {qtdeEspaco} espaços em branco");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int qtdeR = 0;
            foreach (char c in richTextFrase.Text.ToUpper())
            {
                if (c == 'R')
                {
                    qtdeR++;
                }
            }
            MessageBox.Show($"O texto possui {qtdeR} letras R");
        }

        private void btnParLetra_Click(object sender, EventArgs e)
        {
            int qtdePar = 0;

          while 
        }
    }
}
