﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contNum = 0;

            while (contador < rchTxtFrase.Text.Length)
            {
                if (Char.IsNumber(rchTxtFrase.Text[contador]))
                {
                    contNum++;
                }
                    contador++;
            }
            MessageBox.Show("O texto tem " + contNum + "números");
            //interpolação
            MessageBox.Show($"O texto tem {contNum} números");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int posição = 0;

            for (int i = 0; i < rchTxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchTxtFrase.Text[i]))
                {
                    posição = i + 1;
                    break;
                }
            }
            MessageBox.Show($"a posição do 1º caracter branco é a {posição}");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int contLetra = 0;
            foreach (char c in rchTxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contLetra++;
                }
            }
            MessageBox.Show($"otexto tem{contLetra} letras");
        }
    }
}
