﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pratica_Lp2_Aula6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                if (Application.OpenForms.OfType<fmrExercicio1>().Count() > 0)
                {
                    MessageBox.Show("Form já existe");
                    Application.OpenForms["fmrExercicio1"].BringToFront();
                }
                else
                {
                    fmrExercicio1 obj2 = new fmrExercicio1();
                    obj2.MdiParent = this;
                    obj2.WindowState = FormWindowState.Maximized;
                    obj2.Show();
                }
            }
        }
    }
}
