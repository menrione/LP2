﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFerramenta0030482421006
{
    public partial class frmFerramenta : Form
    {
        private BindingSource bnFerramenta = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();
        private DataSet dsFabricante = new DataSet();

        public frmFerramenta()
        {
            InitializeComponent();
        }

        private void btnNovoRegistro_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }
            bnFerramenta.AddNew();

            txtNome.Enabled = true;
            txtNome.Focus();
            txtSite.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpDtCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;

            cbxFabricante.SelectedIndex = 0;
            cbxCategoria.SelectedIndex = 0;
            cbxDistribuicao.SelectedIndex = 0;

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;

            bInclusao = true;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Ferramenta RegFer = new Ferramenta();
                RegFer.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);

                if (RegFer.Excluir() > 0)
                {
                    MessageBox.Show("Ferramenta excluida com sucesso!");

                    dsFerramenta.Tables.Clear();
                    dsFerramenta.Tables.Add(RegFer.Listar());
                    bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];

                }
                else
                {
                    MessageBox.Show("Erro ao excluir ferramenta!");
                }
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || (txtNome.Text.Replace(" ", "").Length < 1))
            {
                MessageBox.Show("Nome inválido!");
            }
            else if (txtSite.Text == "" || txtSite.Text.Replace(" ", "").Length < 8)
            {
                MessageBox.Show("Site oficial inválido!");
            }
            else if (Convert.ToDateTime(dtpDtCadastro.Value) < DateTime.Today)
            {
                MessageBox.Show("Data inválida!");
            }
            else if (cbxFabricante.SelectedIndex == -1)
            {
                MessageBox.Show("Fabricante inválido!");
            }
            else
            {
                Ferramenta RegFer = new Ferramenta();
                RegFer.Nome = txtNome.Text;
                RegFer.Distribuicao = Convert.ToChar(cbxDistribuicao.SelectedItem);
                RegFer.DtCadastro = dtpDtCadastro.Value;
                RegFer.SiteOficial = txtSite.Text;
                RegFer.IdCategoria = Convert.ToInt32(cbxCategoria.SelectedValue.ToString());
                RegFer.IdFabricante = Convert.ToInt32(cbxFabricante.SelectedValue.ToString());

                if (bInclusao)
                {
                    if (RegFer.Salvar() > 0)
                    {
                        MessageBox.Show("Ferramenta adicionada com sucesso!");

                        txtNome.Enabled = false;
                        txtSite.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpDtCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnNovoRegistro.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFer.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Ferramenta!");
                    }
                }
                else
                {
                    RegFer.IdFerramenta = Convert.ToInt32(txtIdFerramenta.Text);

                    if (RegFer.Alterar() > 0)
                    {
                        MessageBox.Show("Ferramenta alterada com sucesso!");

                        txtNome.Enabled = false;
                        txtSite.Enabled = false;
                        cbxDistribuicao.Enabled = false;
                        dtpDtCadastro.Enabled = false;
                        cbxCategoria.Enabled = false;
                        cbxFabricante.Enabled = false;

                        btnNovoRegistro.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegFer.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar Ferramenta!");
                    }
                }

            }

        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }
            txtNome.Enabled = true;
            txtSite.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpDtCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;

            btnNovoRegistro.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = false;

        }



        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bnFerramenta.CancelEdit();

            txtNome.Enabled = false;
            txtSite.Enabled = false;
            cbxDistribuicao.Enabled = false;
            dtpDtCadastro.Enabled = false;
            cbxCategoria.Enabled = false;
            cbxFabricante.Enabled = false;

            btnNovoRegistro.Enabled = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;

            bInclusao = false;

        }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {
            try
            {
                Ferramenta RegFer = new Ferramenta();
                dsFerramenta.Tables.Add(RegFer.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["FERRAMENTA"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                txtIdFerramenta.DataBindings.Add("TEXT", bnFerramenta, "id");
                txtNome.DataBindings.Add("TEXT", bnFerramenta, "nome");
                cbxDistribuicao.DataBindings.Add("SelectedItem", bnFerramenta, "distribuicao");
                dtpDtCadastro.DataBindings.Add("TEXT", bnFerramenta, "dtcadastro");
                txtSite.DataBindings.Add("TEXT", bnFerramenta, "siteoficial");

                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());
                cbxCategoria.DataSource = dsCategoria.Tables["categoria"];
                cbxCategoria.DisplayMember = "descricao";
                cbxCategoria.ValueMember = "id";
                cbxCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "idCategoria");

                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                cbxFabricante.DataSource = dsFabricante.Tables["fabricante"];
                cbxFabricante.DisplayMember = "nomefantasia";
                cbxFabricante.ValueMember = "id";
                cbxFabricante.DataBindings.Add("SelectedValue", bnFerramenta, "idFabricante");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
