﻿namespace pratica_Lp2_Aula6
{
    partial class fmrExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnParLetra = new System.Windows.Forms.Button();
            this.richTextFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(65, 330);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(185, 88);
            this.btnEspaco.TabIndex = 1;
            this.btnEspaco.Text = "Número de Espaços";
            this.btnEspaco.UseVisualStyleBackColor = true;
            this.btnEspaco.Click += new System.EventHandler(this.btnEspaco_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(297, 331);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(170, 86);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Qtde Letra R";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnParLetra
            // 
            this.btnParLetra.Location = new System.Drawing.Point(512, 333);
            this.btnParLetra.Name = "btnParLetra";
            this.btnParLetra.Size = new System.Drawing.Size(173, 84);
            this.btnParLetra.TabIndex = 3;
            this.btnParLetra.Text = "Qtde Pares de Letras";
            this.btnParLetra.UseVisualStyleBackColor = true;
            this.btnParLetra.Click += new System.EventHandler(this.btnParLetra_Click);
            // 
            // richTextFrase
            // 
            this.richTextFrase.Location = new System.Drawing.Point(133, 43);
            this.richTextFrase.MaxLength = 100;
            this.richTextFrase.Name = "richTextFrase";
            this.richTextFrase.Size = new System.Drawing.Size(506, 241);
            this.richTextFrase.TabIndex = 4;
            this.richTextFrase.Text = "";
            // 
            // fmrExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.richTextFrase);
            this.Controls.Add(this.btnParLetra);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspaco);
            this.Name = "fmrExercicio1";
            this.Text = "fmrExercicio1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnParLetra;
        private System.Windows.Forms.RichTextBox richTextFrase;
    }
}